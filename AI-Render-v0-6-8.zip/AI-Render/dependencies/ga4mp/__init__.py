# NOTE: Version 2.0.4
# modified by @benrugg to fix Blender's Python SSL certificate verification failure

from ga4mp.ga4mp import GtagMP, FirebaseMP

__all__ = ['GtagMP','FirebaseMP']
